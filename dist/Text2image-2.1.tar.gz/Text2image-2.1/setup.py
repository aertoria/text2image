from setuptools import setup, find_packages
setup(name='Text2image',
      version='2.1',
      description='Python text2image Text2image',
      author='aertoria',
      author_email='ethanwang.dev@gmail.com',
      url='https://www.python.org',
      packages = find_packages(),
      include_package_data=True,
      license = "Apache License, Version 2.0",
     )